# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['tictactoe']
install_requires = \
['beartype>=0.10.4,<0.11.0',
 'formate-black>=0.2.0,<0.3.0',
 'mypy>=0.942,<0.943',
 'pydantic-validators>=0.1.0,<0.2.0',
 'pyls-isort>=0.2.2,<0.3.0',
 'pyre2>=0.3.6,<0.4.0']

setup_kwargs = {
    'name': 'tictactoe',
    'version': '0.1.0',
    'description': 'tictactoe boilerplate with unbeatable ai',
    'long_description': None,
    'author': 'Wizock',
    'author_email': 'silent.death3500@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
